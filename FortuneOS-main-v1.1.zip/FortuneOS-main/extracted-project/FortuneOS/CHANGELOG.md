# FortuneOS — cambios de la versión 1.1.0 (versionCode 2)

## Rendimiento
- La pantalla de inicio ya no redibuja en bucle con `Canvas`. Ahora usa vistas XML normales.
- La hora y la batería se actualizan con broadcasts del sistema, no consultando en cada fotograma.
- El cajón de aplicaciones usa `RecyclerView`, una lista cacheada en segundo plano y una caché de iconos (LruCache).
- Se eliminaron las forzaciones de versiones antiguas de AndroidX y el bloque de empaquetado de Kotlin Multiplatform.
- Se eliminaron dependencias sin uso (constraintlayout, interpolator, startup-runtime) y el layout muerto.

## Tamaños y tacto
- Todos los tamaños de texto y botones se expresan en `sp` y `dp`, nunca en píxeles fijos.
- Los accesos directos cumplen un mínimo de 48 dp de zona táctil.
- Edge-to-edge con inserciones del sistema (obligatorio en Android 15).

## Accesibilidad e idioma
- Todos los textos están en `strings.xml` en español.
- Los accesos directos son controles reales y tienen descripción para TalkBack.

## Proyectos
- Modelo completo: nombre, descripción, repositorio, enlace, aplicaciones asociadas, archivos, estado, último acceso, notas y próximos pasos.
- Añadir, editar, eliminar y reordenar (pulsación prolongada).
- Los archivos se adjuntan a cada proyecto desde el selector oficial o desde la biblioteca.
- Eliminar un proyecto solo borra su ficha. Quitar un archivo solo quita la referencia y libera el permiso.
- Los datos se migran de la versión anterior sin pérdida. Un nombre con `|` ya no desaparece.

## Privacidad
- Ajustes para desactivar el registro de uso (al desactivarlo se borran los datos) y las sugerencias.
- Todo se guarda solo en el teléfono. No hay red ni claves.

## Launcher
- `MainActivity` usa `singleTask` y no se cierra con Atrás.
- Acceso desde Ajustes a la configuración de inicio de Android.

## No incluido todavía
- Iconos del dock: se usan los iconos del sistema como marcador provisional.
- Base de datos relacional (Room) y sugerencias por relaciones: está previsto para la Etapa B.
- Integración con IA: no implementada.
- Pruebas unitarias: no hay todavía.

## Verificación
- Recursos XML validados sintácticamente y referencias comprobadas (IDs, cadenas, layouts, colores, estilos).
- Compilación y pruebas en el dispositivo: pendientes. Se verifican con el workflow `android-build.yml`.
