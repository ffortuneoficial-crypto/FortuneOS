package com.fortune.os.data

import android.content.Context
import android.net.Uri
import com.fortune.os.util.FileAccess
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Almacén local de FortuneOS. Mantiene una copia en memoria y la persiste como un único
 * JSON en SharedPreferences. Las lecturas no tocan el disco; las escrituras son pequeñas.
 * Los datos de la versión anterior (formato "nombre|url") se migran la primera vez.
 */
class FortuneStore private constructor(context: Context) {

    private val app = context.applicationContext
    private val dataPrefs = app.getSharedPreferences("fortuneos", Context.MODE_PRIVATE)
    private val usagePrefs = app.getSharedPreferences("fortuneos_usage", Context.MODE_PRIVATE)
    private val settingsPrefs = app.getSharedPreferences("fortuneos_settings", Context.MODE_PRIVATE)

    private val projectList = mutableListOf<Project>()
    private val fileList = mutableListOf<SavedFile>()

    init {
        load()
    }

    // ---- Ajustes de privacidad -------------------------------------------------------

    var usageTrackingEnabled: Boolean
        get() = settingsPrefs.getBoolean(KEY_USAGE, true)
        set(value) {
            settingsPrefs.edit().putBoolean(KEY_USAGE, value).apply()
            if (!value) clearUsage()
        }

    var suggestionsEnabled: Boolean
        get() = settingsPrefs.getBoolean(KEY_SUGGEST, true)
        set(value) {
            settingsPrefs.edit().putBoolean(KEY_SUGGEST, value).apply()
        }

    // ---- Uso de aplicaciones ----------------------------------------------------------

    fun recordLaunch(packageName: String) {
        if (!usageTrackingEnabled) return
        val key = USE_PREFIX + packageName
        usagePrefs.edit().putInt(key, usagePrefs.getInt(key, 0) + 1).apply()
    }

    fun usageOf(packageName: String): Int = usagePrefs.getInt(USE_PREFIX + packageName, 0)

    fun clearUsage() {
        usagePrefs.edit().clear().apply()
    }

    // ---- Proyectos --------------------------------------------------------------------

    /** Devuelve los proyectos en el orden que eligió el usuario. */
    fun projects(): List<Project> = projectList.toList()

    fun project(id: String): Project? = projectList.firstOrNull { it.id == id }

    fun newId(): String = UUID.randomUUID().toString()

    fun saveProject(project: Project) {
        val index = projectList.indexOfFirst { it.id == project.id }
        if (index >= 0) projectList[index] = project else projectList.add(project)
        persist()
    }

    fun deleteProject(id: String) {
        projectList.removeAll { it.id == id }
        persist()
    }

    fun reorder(ids: List<String>) {
        val byId = projectList.associateBy { it.id }
        val ordered = ids.mapNotNull { byId[it] }
        val rest = projectList.filter { it.id !in ids }
        projectList.clear()
        projectList.addAll(ordered + rest)
        persist()
    }

    /** Registra un acceso. Respeta el ajuste de registro de uso. */
    fun touch(id: String) {
        if (!usageTrackingEnabled) return
        val index = projectList.indexOfFirst { it.id == id }
        if (index < 0) return
        projectList[index] = projectList[index].copy(lastAccess = System.currentTimeMillis())
        persist()
    }

    // ---- Biblioteca de archivos -------------------------------------------------------

    fun files(): List<SavedFile> = fileList.toList()

    fun file(id: String): SavedFile? = fileList.firstOrNull { it.id == id }

    /** Añade la referencia (sin duplicar) y conserva el permiso de lectura persistente. */
    fun addFile(context: Context, uri: Uri): SavedFile {
        val raw = uri.toString()
        fileList.firstOrNull { it.uri == raw }?.let { return it }
        FileAccess.takeRead(context, uri)
        val saved = SavedFile(
            id = newId(),
            uri = raw,
            name = FileAccess.displayName(context, uri),
            mime = context.contentResolver.getType(uri),
            addedAt = System.currentTimeMillis()
        )
        fileList.add(0, saved)
        persist()
        return saved
    }

    /** Quita la referencia y de todos los proyectos. No borra el archivo original. */
    fun removeFile(id: String): SavedFile? {
        val removed = fileList.firstOrNull { it.id == id } ?: return null
        fileList.remove(removed)
        for (i in projectList.indices) {
            val p = projectList[i]
            if (id in p.fileIds) projectList[i] = p.copy(fileIds = p.fileIds - id)
        }
        persist()
        return removed
    }

    // ---- Persistencia -----------------------------------------------------------------

    private fun persist() {
        val root = JSONObject()
            .put("projects", JSONArray().apply { projectList.forEach { put(it.toJson()) } })
            .put("files", JSONArray().apply { fileList.forEach { put(it.toJson()) } })
        dataPrefs.edit().putString(KEY_DATA, root.toString()).commit()
    }

    private fun load() {
        val raw = dataPrefs.getString(KEY_DATA, null)
        if (raw == null) {
            migrateLegacy()
            persist()
            return
        }
        try {
            val root = JSONObject(raw)
            root.optJSONArray("projects")?.let { arr ->
                for (i in 0 until arr.length()) projectList.add(projectFromJson(arr.getJSONObject(i)))
            }
            root.optJSONArray("files")?.let { arr ->
                for (i in 0 until arr.length()) fileList.add(fileFromJson(arr.getJSONObject(i)))
            }
        } catch (_: Exception) {
            // Datos dañados: se guarda una copia de seguridad y se empieza con un estado limpio.
            projectList.clear()
            fileList.clear()
            dataPrefs.edit().putString(KEY_BROKEN_BACKUP, raw).apply()
        }
    }

    /** Convierte los datos de la primera versión sin perderlos. */
    private fun migrateLegacy() {
        DEFAULT_PROJECTS.forEach { projectList.add(it.copy(id = newId())) }

        val lastProject = dataPrefs.getString("last_project", null)
        dataPrefs.getString("projects", "").orEmpty().lines().forEach { line ->
            // Se usa el último '|' para que los nombres que contienen '|' no se pierdan.
            val cut = line.lastIndexOf('|')
            if (cut <= 0) return@forEach
            val name = line.substring(0, cut).trim()
            val url = line.substring(cut + 1).trim()
            if (name.isEmpty() || !url.startsWith("https://")) return@forEach
            projectList.removeAll { it.name == name }
            val isRepo = url.contains("github.com")
            projectList.add(
                Project(
                    id = newId(),
                    name = name,
                    repoUrl = if (isRepo) url else "",
                    appUrl = if (isRepo) "" else url
                )
            )
        }
        lastProject?.let { name ->
            val index = projectList.indexOfFirst { it.name == name }
            if (index >= 0) {
                projectList[index] = projectList[index].copy(lastAccess = System.currentTimeMillis())
            }
        }

        dataPrefs.getString("saved_files", "").orEmpty().lines()
            .filter { it.isNotBlank() }
            .forEach { raw ->
                if (fileList.none { it.uri == raw }) {
                    val uri = Uri.parse(raw)
                    fileList.add(
                        SavedFile(
                            id = newId(),
                            uri = raw,
                            name = FileAccess.displayName(app, uri),
                            mime = app.contentResolver.getType(uri),
                            addedAt = System.currentTimeMillis()
                        )
                    )
                }
            }
    }

    companion object {
        private const val KEY_DATA = "data_v2"
        private const val KEY_BROKEN_BACKUP = "data_v2_backup_corrupt"
        private const val KEY_USAGE = "usage_enabled"
        private const val KEY_SUGGEST = "suggestions_enabled"
        private const val USE_PREFIX = "use_"

        /** Proyectos de ejemplo de la versión anterior. El usuario puede editarlos o borrarlos. */
        private val DEFAULT_PROJECTS = listOf(
            Project(id = "", name = "Fortune Web", repoUrl = "https://github.com/ffortuneoficial-crypto/WebFortune"),
            Project(id = "", name = "GitHub · proyectos", appUrl = "https://github.com/ffortuneoficial-crypto"),
            Project(id = "", name = "Supabase · datos", appUrl = "https://supabase.com/dashboard"),
            Project(id = "", name = "FortuneOS · Código", repoUrl = "https://github.com/ffortuneoficial-crypto/FortuneOS")
        )

        @Volatile
        private var instance: FortuneStore? = null

        fun get(context: Context): FortuneStore =
            instance ?: synchronized(this) {
                instance ?: FortuneStore(context).also { instance = it }
            }
    }
}

private fun Project.toJson(): JSONObject = JSONObject()
    .put("id", id)
    .put("name", name)
    .put("description", description)
    .put("repoUrl", repoUrl)
    .put("appUrl", appUrl)
    .put("status", status.name)
    .put("lastAccess", lastAccess)
    .put("notes", notes)
    .put("nextSteps", nextSteps)
    .put("packages", JSONArray(packages))
    .put("fileIds", JSONArray(fileIds))

private fun SavedFile.toJson(): JSONObject = JSONObject()
    .put("id", id)
    .put("uri", uri)
    .put("name", name)
    .put("mime", mime ?: JSONObject.NULL)
    .put("addedAt", addedAt)

private fun JSONArray.strings(): List<String> = (0 until length()).map { getString(it) }

private fun projectFromJson(o: JSONObject): Project = Project(
    id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
    name = o.optString("name"),
    description = o.optString("description"),
    repoUrl = o.optString("repoUrl"),
    appUrl = o.optString("appUrl"),
    status = ProjectStatus.fromName(o.optString("status")),
    lastAccess = o.optLong("lastAccess", 0L),
    notes = o.optString("notes"),
    nextSteps = o.optString("nextSteps"),
    packages = o.optJSONArray("packages")?.strings().orEmpty(),
    fileIds = o.optJSONArray("fileIds")?.strings().orEmpty()
)

private fun fileFromJson(o: JSONObject): SavedFile = SavedFile(
    id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
    uri = o.optString("uri"),
    name = o.optString("name"),
    mime = o.optString("mime", "").ifBlank { null },
    addedAt = o.optLong("addedAt", 0L)
)
