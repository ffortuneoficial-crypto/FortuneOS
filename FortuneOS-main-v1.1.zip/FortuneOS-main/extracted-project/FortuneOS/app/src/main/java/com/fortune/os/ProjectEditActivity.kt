package com.fortune.os

import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.fortune.os.data.AppCatalog
import com.fortune.os.data.FortuneStore
import com.fortune.os.data.Project
import com.fortune.os.data.ProjectStatus
import com.fortune.os.ui.FileRow
import com.fortune.os.ui.Rows
import com.fortune.os.util.Apps
import com.fortune.os.util.Chrome
import com.fortune.os.util.FileAccess
import com.fortune.os.util.Launch
import com.fortune.os.util.Links

class ProjectEditActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ID = "project_id"
        private const val KEY_PACKAGES = "packages"
        private const val KEY_FILES = "files"
    }

    private lateinit var store: FortuneStore
    private lateinit var nameField: EditText
    private lateinit var descField: EditText
    private lateinit var repoField: EditText
    private lateinit var linkField: EditText
    private lateinit var notesField: EditText
    private lateinit var nextField: EditText
    private lateinit var statusSpinner: Spinner
    private lateinit var appsSummary: TextView
    private lateinit var filesBox: LinearLayout

    private var editingId: String? = null
    private val packages = LinkedHashSet<String>()
    private val attached = LinkedHashSet<String>()

    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val file = store.addFile(this, uri)
            attached.add(file.id)
            renderFiles()
            Launch.toast(this, R.string.files_saved)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_project_edit)
        Chrome.edgeToEdge(this, findViewById(R.id.edit_root))
        store = FortuneStore.get(this)

        nameField = findViewById(R.id.edit_name)
        descField = findViewById(R.id.edit_description)
        repoField = findViewById(R.id.edit_repo)
        linkField = findViewById(R.id.edit_link)
        notesField = findViewById(R.id.edit_notes)
        nextField = findViewById(R.id.edit_next)
        statusSpinner = findViewById(R.id.edit_status)
        appsSummary = findViewById(R.id.edit_apps_summary)
        filesBox = findViewById(R.id.edit_files)

        statusSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_item,
            ProjectStatus.entries.map { getString(it.labelRes) }
        ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }

        editingId = intent.getStringExtra(EXTRA_ID)
        val existing = editingId?.let { store.project(it) }
        findViewById<TextView>(R.id.edit_title).setText(
            if (existing == null) R.string.edit_title_new else R.string.edit_title_edit
        )
        if (existing != null) {
            nameField.setText(existing.name)
            descField.setText(existing.description)
            repoField.setText(existing.repoUrl)
            linkField.setText(existing.appUrl)
            notesField.setText(existing.notes)
            nextField.setText(existing.nextSteps)
            statusSpinner.setSelection(existing.status.ordinal)
            packages.addAll(existing.packages)
            attached.addAll(existing.fileIds)
        }
        savedInstanceState?.let { state ->
            packages.clear()
            packages.addAll(state.getStringArrayList(KEY_PACKAGES).orEmpty())
            attached.clear()
            attached.addAll(state.getStringArrayList(KEY_FILES).orEmpty())
        }

        findViewById<View>(R.id.btn_apps).setOnClickListener { chooseApps() }
        findViewById<View>(R.id.btn_attach).setOnClickListener { pickFile.launch(arrayOf("*/*")) }
        findViewById<View>(R.id.btn_library).setOnClickListener { chooseFromLibrary() }
        findViewById<View>(R.id.btn_save).setOnClickListener { save() }
        findViewById<View>(R.id.btn_cancel).setOnClickListener { finish() }

        renderPackages()
        renderFiles()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putStringArrayList(KEY_PACKAGES, ArrayList(packages))
        outState.putStringArrayList(KEY_FILES, ArrayList(attached))
    }

    private fun renderPackages() {
        appsSummary.text = if (packages.isEmpty()) {
            getString(R.string.edit_apps_none)
        } else {
            packages.joinToString(", ") { Apps.label(this, it) ?: it }
        }
    }

    private fun renderFiles() {
        filesBox.removeAllViews()
        if (attached.isEmpty()) {
            filesBox.addView(Rows.placeholder(filesBox, R.string.edit_no_files))
            return
        }
        attached.toList().forEach { id ->
            val file = store.file(id) ?: return@forEach
            val row = LayoutInflater.from(this).inflate(R.layout.item_file, filesBox, false)
            FileRow.bind(
                row = row,
                file = file,
                hasAccess = FileAccess.hasAccess(this, Uri.parse(file.uri)),
                actionRes = R.string.edit_detach,
                onAction = {
                    attached.remove(id)
                    renderFiles()
                },
                onOpen = null
            )
            filesBox.addView(row)
        }
    }

    private fun chooseApps() {
        AppCatalog.load(this) { list ->
            if (isDestroyed) return@load
            val labels = list.map { it.label }.toTypedArray()
            val checked = list.map { it.packageName in packages }.toBooleanArray()
            AlertDialog.Builder(this)
                .setTitle(R.string.edit_apps_choose)
                .setMultiChoiceItems(labels, checked) { _, which, isChecked ->
                    checked[which] = isChecked
                }
                .setPositiveButton(R.string.common_ok) { _, _ ->
                    // Se conservan los paquetes que ya no aparecen en el listado (p. ej. desinstalados).
                    val listed = list.map { it.packageName }.toSet()
                    val hidden = packages.filter { it !in listed }
                    packages.clear()
                    packages.addAll(hidden)
                    list.forEachIndexed { i, app -> if (checked[i]) packages.add(app.packageName) }
                    renderPackages()
                }
                .setNegativeButton(R.string.common_cancel, null)
                .show()
        }
    }

    private fun chooseFromLibrary() {
        val files = store.files()
        if (files.isEmpty()) {
            Launch.toast(this, R.string.files_empty)
            return
        }
        val labels = files.map { it.name }.toTypedArray()
        val checked = files.map { it.id in attached }.toBooleanArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.edit_library)
            .setMultiChoiceItems(labels, checked) { _, which, isChecked ->
                checked[which] = isChecked
            }
            .setPositiveButton(R.string.common_ok) { _, _ ->
                attached.clear()
                files.forEachIndexed { i, file -> if (checked[i]) attached.add(file.id) }
                renderFiles()
            }
            .setNegativeButton(R.string.common_cancel, null)
            .show()
    }

    private fun save() {
        val name = nameField.text.toString().trim()
        val repo = repoField.text.toString().trim()
        val link = linkField.text.toString().trim()
        if (name.isEmpty()) {
            nameField.error = getString(R.string.edit_name_required)
            return
        }
        if (!Links.isOptionalHttps(repo) || !Links.isOptionalHttps(link)) {
            Launch.toast(this, R.string.edit_url_invalid)
            return
        }
        val existing = editingId?.let { store.project(it) }
        store.saveProject(
            Project(
                id = existing?.id ?: store.newId(),
                name = name,
                description = descField.text.toString().trim(),
                repoUrl = repo,
                appUrl = link,
                status = ProjectStatus.entries[statusSpinner.selectedItemPosition],
                lastAccess = existing?.lastAccess ?: 0L,
                notes = notesField.text.toString().trim(),
                nextSteps = nextField.text.toString().trim(),
                packages = packages.toList(),
                fileIds = attached.toList()
            )
        )
        Launch.toast(this, R.string.edit_saved)
        finish()
    }
}
