package com.fortune.os.util

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.OpenableColumns
import android.view.View
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.fortune.os.R
import com.fortune.os.data.SavedFile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Respeta las barras del sistema (edge-to-edge obligatorio desde Android 15). */
object Chrome {
    fun edgeToEdge(activity: Activity, root: View) {
        WindowCompat.setDecorFitsSystemWindows(activity.window, false)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }
    }
}

object Formats {
    private const val DAY_MS = 86_400_000L

    fun relative(ctx: Context, time: Long): String {
        if (time <= 0L) return ctx.getString(R.string.time_never)
        val days = ((System.currentTimeMillis() - time) / DAY_MS).toInt()
        return when {
            days <= 0 -> ctx.getString(R.string.time_today)
            days == 1 -> ctx.getString(R.string.time_yesterday)
            else -> ctx.getString(R.string.time_days, days)
        }
    }

    fun date(time: Long): String =
        SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(time))
}

object Links {
    fun isHttps(url: String): Boolean {
        val host = Uri.parse(url).host
        return url.startsWith("https://") && !host.isNullOrBlank()
    }

    fun isOptionalHttps(url: String): Boolean = url.isBlank() || isHttps(url)
}

object Apps {
    /** Nombre visible de un paquete instalado, o null si no está instalado. */
    fun label(ctx: Context, packageName: String): String? = try {
        val pm = ctx.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(packageName, 0)).toString()
    } catch (_: PackageManager.NameNotFoundException) {
        null
    }
}

/** Acceso a archivos mediante permisos de URI persistentes. */
object FileAccess {
    fun takeRead(ctx: Context, uri: Uri) {
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: SecurityException) {
            // Algunos proveedores no ofrecen permisos persistentes.
        } catch (_: IllegalArgumentException) {
        }
    }

    fun hasAccess(ctx: Context, uri: Uri): Boolean =
        ctx.contentResolver.persistedUriPermissions.any { it.uri == uri && it.isReadPermission }

    fun release(ctx: Context, uri: Uri) {
        try {
            ctx.contentResolver.releasePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: SecurityException) {
        } catch (_: IllegalArgumentException) {
        }
    }

    fun displayName(ctx: Context, uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val index = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index >= 0) {
                        val name = c.getString(index)
                        if (!name.isNullOrBlank()) return name
                    }
                }
            }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':')
            ?.takeIf { it.isNotBlank() } ?: "Archivo"
    }
}

/** Lanza intents sin fallar: cualquier error se muestra como aviso breve. */
object Launch {
    fun start(ctx: Context, intent: Intent, errorRes: Int): Boolean {
        if (ctx !is Activity) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(intent)
            true
        } catch (_: ActivityNotFoundException) {
            toast(ctx, errorRes)
            false
        } catch (_: SecurityException) {
            toast(ctx, errorRes)
            false
        }
    }

    fun url(ctx: Context, url: String): Boolean =
        if (Links.isHttps(url)) {
            start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)), R.string.err_open_link)
        } else {
            toast(ctx, R.string.err_open_link)
            false
        }

    fun packageApp(ctx: Context, packageName: String): Boolean {
        val intent = ctx.packageManager.getLaunchIntentForPackage(packageName)
        if (intent == null) {
            toast(ctx, R.string.err_open_app)
            return false
        }
        return start(ctx, intent, R.string.err_open_app)
    }

    fun file(ctx: Context, file: SavedFile): Boolean {
        val uri = Uri.parse(file.uri)
        if (!FileAccess.hasAccess(ctx, uri)) {
            toast(ctx, R.string.files_no_access_toast)
            return false
        }
        val type = file.mime ?: ctx.contentResolver.getType(uri) ?: "*/*"
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, type)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        return start(ctx, intent, R.string.files_open_fail)
    }

    fun toast(ctx: Context, textRes: Int) {
        Toast.makeText(ctx, textRes, Toast.LENGTH_SHORT).show()
    }
}
