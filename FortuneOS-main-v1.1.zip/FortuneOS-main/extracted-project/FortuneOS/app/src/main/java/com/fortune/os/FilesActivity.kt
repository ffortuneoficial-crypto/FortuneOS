package com.fortune.os

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.fortune.os.data.FortuneStore
import com.fortune.os.data.SavedFile
import com.fortune.os.ui.FileAdapter
import com.fortune.os.util.Chrome
import com.fortune.os.util.FileAccess
import com.fortune.os.util.Launch

class FilesActivity : AppCompatActivity() {

    private lateinit var store: FortuneStore
    private lateinit var empty: TextView
    private lateinit var adapter: FileAdapter

    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            store.addFile(this, uri)
            Launch.toast(this, R.string.files_saved)
            refresh()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_files)
        Chrome.edgeToEdge(this, findViewById(R.id.files_root))
        store = FortuneStore.get(this)
        empty = findViewById(R.id.empty)

        adapter = FileAdapter(
            onOpen = { Launch.file(this, it) },
            onRemove = { confirmRemove(it) }
        )
        val list = findViewById<RecyclerView>(R.id.files)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        findViewById<View>(R.id.btn_add_file).setOnClickListener { pickFile.launch(arrayOf("*/*")) }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val files = store.files()
        val accessible = contentResolver.persistedUriPermissions
            .filter { it.isReadPermission }
            .map { it.uri.toString() }
            .toSet()
        adapter.submit(files, accessible)
        empty.visibility = if (files.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun confirmRemove(file: SavedFile) {
        AlertDialog.Builder(this)
            .setTitle(R.string.files_remove)
            .setMessage(R.string.files_remove_msg)
            .setPositiveButton(R.string.common_remove) { _, _ ->
                val removed = store.removeFile(file.id)
                if (removed != null) FileAccess.release(this, Uri.parse(removed.uri))
                Launch.toast(this, R.string.files_removed)
                refresh()
            }
            .setNegativeButton(R.string.common_cancel, null)
            .show()
    }
}
