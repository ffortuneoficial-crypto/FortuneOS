package com.fortune.os

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import com.fortune.os.data.FortuneStore
import com.fortune.os.ui.FileRow
import com.fortune.os.ui.Rows
import com.fortune.os.util.Apps
import com.fortune.os.util.Chrome
import com.fortune.os.util.FileAccess
import com.fortune.os.util.Formats
import com.fortune.os.util.Launch

class ProjectDetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ID = "project_id"
    }

    private lateinit var store: FortuneStore
    private var projectId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_project_detail)
        Chrome.edgeToEdge(this, findViewById(R.id.detail_root))
        store = FortuneStore.get(this)
        projectId = intent.getStringExtra(EXTRA_ID).orEmpty()

        findViewById<View>(R.id.btn_edit).setOnClickListener {
            startActivity(
                Intent(this, ProjectEditActivity::class.java)
                    .putExtra(ProjectEditActivity.EXTRA_ID, projectId)
            )
        }
        findViewById<View>(R.id.btn_delete).setOnClickListener { confirmDelete() }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        val p = store.project(projectId) ?: run {
            finish()
            return
        }
        findViewById<TextView>(R.id.detail_title).text = p.name
        findViewById<TextView>(R.id.detail_status).setText(p.status.labelRes)
        findViewById<TextView>(R.id.detail_last).text =
            getString(R.string.detail_last, Formats.relative(this, p.lastAccess))

        showOptional(R.id.detail_description, R.id.detail_description, p.description)
        showOptional(R.id.detail_notes, R.id.notes_block, p.notes)
        showOptional(R.id.detail_next, R.id.next_block, p.nextSteps)

        bindLink(R.id.btn_repo, p.repoUrl)
        bindLink(R.id.btn_link, p.appUrl)
        renderPackages(p.packages)
        renderFiles(p.fileIds)
    }

    private fun showOptional(textId: Int, blockId: Int, text: String) {
        findViewById<TextView>(textId).text = text
        findViewById<View>(blockId).visibility = if (text.isBlank()) View.GONE else View.VISIBLE
    }

    private fun bindLink(buttonId: Int, url: String) {
        val button = findViewById<View>(buttonId)
        button.visibility = if (url.isBlank()) View.GONE else View.VISIBLE
        button.setOnClickListener {
            store.touch(projectId)
            Launch.url(this, url)
        }
    }

    private fun renderPackages(ids: List<String>) {
        val box = findViewById<LinearLayout>(R.id.packages_container)
        box.removeAllViews()
        if (ids.isEmpty()) {
            box.addView(Rows.placeholder(box, R.string.detail_none_apps))
            return
        }
        ids.forEach { pkg ->
            val label = Apps.label(this, pkg)
            box.addView(
                Rows.link(box, label ?: getString(R.string.detail_app_missing), label != null) {
                    store.touch(projectId)
                    Launch.packageApp(this, pkg)
                }
            )
        }
    }

    private fun renderFiles(ids: List<String>) {
        val box = findViewById<LinearLayout>(R.id.files_container)
        box.removeAllViews()
        val files = ids.mapNotNull { store.file(it) }
        if (files.isEmpty()) {
            box.addView(Rows.placeholder(box, R.string.detail_none_files))
            return
        }
        files.forEach { file ->
            val row = layoutInflater.inflate(R.layout.item_file, box, false)
            FileRow.bind(
                row = row,
                file = file,
                hasAccess = FileAccess.hasAccess(this, Uri.parse(file.uri)),
                actionRes = null,
                onAction = null,
                onOpen = {
                    store.touch(projectId)
                    Launch.file(this, file)
                }
            )
            box.addView(row)
        }
    }

    private fun confirmDelete() {
        AlertDialog.Builder(this)
            .setTitle(R.string.detail_delete_title)
            .setMessage(R.string.detail_delete_msg)
            .setPositiveButton(R.string.common_delete) { _, _ ->
                store.deleteProject(projectId)
                finish()
            }
            .setNegativeButton(R.string.common_cancel, null)
            .show()
    }
}
