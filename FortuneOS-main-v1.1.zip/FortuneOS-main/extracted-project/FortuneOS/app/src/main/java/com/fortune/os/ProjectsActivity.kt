package com.fortune.os

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.fortune.os.data.FortuneStore
import com.fortune.os.ui.ProjectAdapter
import com.fortune.os.util.Chrome

class ProjectsActivity : AppCompatActivity() {

    private lateinit var store: FortuneStore
    private lateinit var adapter: ProjectAdapter
    private lateinit var empty: TextView

    /** Reordenar con pulsación prolongada; el nuevo orden se guarda al soltar. */
    private val reorder = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
        ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0
    ) {
        override fun onMove(
            recyclerView: RecyclerView,
            viewHolder: RecyclerView.ViewHolder,
            target: RecyclerView.ViewHolder
        ): Boolean {
            adapter.move(viewHolder.bindingAdapterPosition, target.bindingAdapterPosition)
            return true
        }

        override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) = Unit

        override fun isLongPressDragEnabled(): Boolean = true

        override fun clearView(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder) {
            super.clearView(recyclerView, viewHolder)
            store.reorder(adapter.ids())
        }
    })

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_projects)
        Chrome.edgeToEdge(this, findViewById(R.id.projects_root))
        store = FortuneStore.get(this)
        empty = findViewById(R.id.empty)

        adapter = ProjectAdapter { project ->
            startActivity(
                Intent(this, ProjectDetailActivity::class.java)
                    .putExtra(ProjectDetailActivity.EXTRA_ID, project.id)
            )
        }
        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        reorder.attachToRecyclerView(list)

        findViewById<View>(R.id.btn_new).setOnClickListener {
            startActivity(Intent(this, ProjectEditActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        val items = store.projects()
        adapter.submit(items)
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }
}
