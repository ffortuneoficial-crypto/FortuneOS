package com.fortune.os.data

import androidx.annotation.StringRes
import com.fortune.os.R

enum class ProjectStatus(@StringRes val labelRes: Int) {
    ACTIVE(R.string.status_active),
    PAUSED(R.string.status_paused),
    IDEA(R.string.status_idea),
    DONE(R.string.status_done);

    companion object {
        fun fromName(name: String?): ProjectStatus =
            ProjectStatus.entries.firstOrNull { it.name == name } ?: ACTIVE
    }
}

/** Proyecto personal. Solo guarda referencias: nunca copia ni borra archivos. */
data class Project(
    val id: String,
    val name: String,
    val description: String = "",
    val repoUrl: String = "",
    val appUrl: String = "",
    val status: ProjectStatus = ProjectStatus.ACTIVE,
    val lastAccess: Long = 0L,
    val notes: String = "",
    val nextSteps: String = "",
    val packages: List<String> = emptyList(),
    val fileIds: List<String> = emptyList()
)

/** Referencia persistente a un archivo elegido con el selector oficial de Android. */
data class SavedFile(
    val id: String,
    val uri: String,
    val name: String,
    val mime: String?,
    val addedAt: Long
)
