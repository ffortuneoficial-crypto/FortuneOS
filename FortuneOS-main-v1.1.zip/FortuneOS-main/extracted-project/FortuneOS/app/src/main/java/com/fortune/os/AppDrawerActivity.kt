package com.fortune.os

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.fortune.os.data.AppCatalog
import com.fortune.os.data.FortuneStore
import com.fortune.os.ui.AppAdapter
import com.fortune.os.util.Chrome
import com.fortune.os.util.Launch
import java.util.Locale

class AppDrawerActivity : AppCompatActivity() {

    private lateinit var store: FortuneStore
    private lateinit var search: EditText
    private lateinit var empty: TextView
    private lateinit var adapter: AppAdapter
    private var all: List<AppCatalog.AppEntry> = emptyList()
    private var loaded = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_drawer)
        Chrome.edgeToEdge(this, findViewById(R.id.drawer_root))
        store = FortuneStore.get(this)

        search = findViewById(R.id.search)
        empty = findViewById(R.id.empty)
        adapter = AppAdapter { app -> openApp(app) }

        val list = findViewById<RecyclerView>(R.id.apps)
        list.layoutManager = LinearLayoutManager(this)
        list.setHasFixedSize(true)
        list.adapter = adapter

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = applyFilter()
            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    override fun onStart() {
        super.onStart()
        AppCatalog.load(this) { list ->
            if (isDestroyed) return@load
            all = list.sortedWith(
                compareByDescending<AppCatalog.AppEntry> { store.usageOf(it.packageName) }
                    .thenBy { it.lower }
            )
            loaded = true
            applyFilter()
        }
    }

    private fun applyFilter() {
        val query = search.text.toString().trim().lowercase(Locale.getDefault())
        val filtered = if (query.isEmpty()) all else all.filter { it.lower.contains(query) }
        adapter.submit(filtered)

        empty.text = getString(if (loaded) R.string.drawer_empty else R.string.drawer_loading)
        empty.visibility = if (filtered.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun openApp(app: AppCatalog.AppEntry) {
        store.recordLaunch(app.packageName)
        if (Launch.packageApp(this, app.packageName)) finish()
    }
}
