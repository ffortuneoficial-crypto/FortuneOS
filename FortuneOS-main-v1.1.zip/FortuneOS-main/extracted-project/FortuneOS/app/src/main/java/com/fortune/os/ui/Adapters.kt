package com.fortune.os.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.fortune.os.R
import com.fortune.os.data.AppCatalog
import com.fortune.os.data.Project
import com.fortune.os.data.SavedFile
import com.fortune.os.util.Formats

class AppAdapter(
    private val onClick: (AppCatalog.AppEntry) -> Unit
) : RecyclerView.Adapter<AppAdapter.Holder>() {

    private var items: List<AppCatalog.AppEntry> = emptyList()

    fun submit(list: List<AppCatalog.AppEntry>) {
        items = list
        notifyDataSetChanged()
    }

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.app_icon)
        val label: TextView = view.findViewById(R.id.app_label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val app = items[position]
        holder.label.text = app.label
        holder.icon.tag = app.packageName
        val cached = AppCatalog.cachedIcon(app.packageName)
        if (cached != null) {
            holder.icon.setImageDrawable(cached)
        } else {
            holder.icon.setImageResource(android.R.drawable.sym_def_app_icon)
            AppCatalog.loadIcon(holder.itemView.context, app.packageName) { drawable ->
                // La vista puede haberse reciclado para otra app mientras se cargaba el icono.
                if (drawable != null && holder.icon.tag == app.packageName) {
                    holder.icon.setImageDrawable(drawable)
                }
            }
        }
        holder.itemView.setOnClickListener { onClick(app) }
    }
}

class ProjectAdapter(
    private val onClick: (Project) -> Unit
) : RecyclerView.Adapter<ProjectAdapter.Holder>() {

    private val items = mutableListOf<Project>()

    fun submit(list: List<Project>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    fun move(from: Int, to: Int) {
        if (from !in items.indices || to !in items.indices) return
        items.add(to, items.removeAt(from))
        notifyItemMoved(from, to)
    }

    fun ids(): List<String> = items.map { it.id }

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.project_name)
        val status: TextView = view.findViewById(R.id.project_status)
        val description: TextView = view.findViewById(R.id.project_description)
        val meta: TextView = view.findViewById(R.id.project_meta)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_project, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val p = items[position]
        holder.name.text = p.name
        holder.status.setText(p.status.labelRes)
        holder.description.text = p.description
        holder.description.visibility = if (p.description.isBlank()) View.GONE else View.VISIBLE
        holder.meta.text = Formats.relative(holder.itemView.context, p.lastAccess)
        holder.itemView.setOnClickListener { onClick(p) }
    }
}

class FileAdapter(
    private val onOpen: (SavedFile) -> Unit,
    private val onRemove: (SavedFile) -> Unit
) : RecyclerView.Adapter<FileAdapter.Holder>() {

    private var items: List<SavedFile> = emptyList()
    private var accessible: Set<String> = emptySet()

    fun submit(list: List<SavedFile>, accessibleUris: Set<String>) {
        items = list
        accessible = accessibleUris
        notifyDataSetChanged()
    }

    class Holder(val view: View) : RecyclerView.ViewHolder(view)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_file, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val file = items[position]
        FileRow.bind(
            row = holder.view,
            file = file,
            hasAccess = file.uri in accessible,
            actionRes = R.string.files_remove,
            onAction = { onRemove(file) },
            onOpen = { onOpen(file) }
        )
    }
}

/** Pinta una fila de archivo; la usan la biblioteca, el detalle y la edición de proyectos. */
object FileRow {
    fun bind(
        row: View,
        file: SavedFile,
        hasAccess: Boolean,
        actionRes: Int?,
        onAction: (() -> Unit)?,
        onOpen: (() -> Unit)?
    ) {
        row.findViewById<TextView>(R.id.file_name).text = file.name
        row.findViewById<TextView>(R.id.file_meta).text =
            if (hasAccess) Formats.date(file.addedAt) else row.context.getString(R.string.files_no_access)

        val action = row.findViewById<TextView>(R.id.file_action)
        if (actionRes != null && onAction != null) {
            action.setText(actionRes)
            action.visibility = View.VISIBLE
            action.setOnClickListener { onAction() }
        } else {
            action.visibility = View.GONE
            action.setOnClickListener(null)
        }

        row.isClickable = onOpen != null
        row.setOnClickListener(if (onOpen != null) View.OnClickListener { onOpen() } else null)
    }
}

/** Filas sencillas para contenedores dentro de un ScrollView (no admiten RecyclerView anidado). */
object Rows {
    fun placeholder(parent: ViewGroup, textRes: Int): TextView =
        (LayoutInflater.from(parent.context).inflate(R.layout.item_link, parent, false) as TextView).apply {
            setText(textRes)
            isClickable = false
            alpha = 0.6f
        }

    fun link(parent: ViewGroup, text: String, enabled: Boolean, onClick: () -> Unit): TextView =
        (LayoutInflater.from(parent.context).inflate(R.layout.item_link, parent, false) as TextView).apply {
            this.text = text
            isEnabled = enabled
            alpha = if (enabled) 1f else 0.5f
            if (enabled) setOnClickListener { onClick() }
        }
}
