package com.fortune.os.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Catálogo de aplicaciones lanzables. La consulta a PackageManager se hace en un hilo de fondo
 * una vez y se reutiliza hasta que un cambio de paquetes lo marca como desactualizado.
 */
object AppCatalog {

    data class AppEntry(val packageName: String, val label: String) {
        val lower: String = label.lowercase(Locale.getDefault())
    }

    private const val ICON_CACHE_SIZE = 120

    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val icons = LruCache<String, Drawable>(ICON_CACHE_SIZE)

    @Volatile
    private var entries: List<AppEntry>? = null

    @Volatile
    private var stale = true

    fun markStale() {
        stale = true
    }

    /** Entrega la lista en el hilo principal. Si ya está en caché, lo hace de inmediato. */
    fun load(context: Context, onResult: (List<AppEntry>) -> Unit) {
        val cached = entries
        if (cached != null && !stale) {
            onResult(cached)
            return
        }
        val app = context.applicationContext
        worker.execute {
            val list = queryLaunchables(app)
            entries = list
            stale = false
            main.post { onResult(list) }
        }
    }

    fun cachedIcon(packageName: String): Drawable? = icons.get(packageName)

    fun loadIcon(context: Context, packageName: String, onResult: (Drawable?) -> Unit) {
        cachedIcon(packageName)?.let {
            onResult(it)
            return
        }
        val app = context.applicationContext
        worker.execute {
            val drawable = try {
                app.packageManager.getApplicationIcon(packageName)
            } catch (_: PackageManager.NameNotFoundException) {
                null
            }
            if (drawable != null) icons.put(packageName, drawable)
            main.post { onResult(drawable) }
        }
    }

    private fun queryLaunchables(context: Context): List<AppEntry> {
        val pm = context.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(query, 0)
            .asSequence()
            .filter { it.activityInfo.packageName != context.packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { AppEntry(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .sortedBy { it.lower }
            .toList()
    }
}
