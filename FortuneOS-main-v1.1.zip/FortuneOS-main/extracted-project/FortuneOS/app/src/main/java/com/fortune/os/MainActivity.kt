package com.fortune.os

import android.animation.ObjectAnimator
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.text.format.DateFormat
import android.view.GestureDetector
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.fortune.os.data.AppCatalog
import com.fortune.os.data.FortuneStore
import com.fortune.os.data.Project
import com.fortune.os.util.Chrome
import com.fortune.os.util.Formats
import com.fortune.os.util.Launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

/**
 * Pantalla de inicio. Todo son vistas normales (tamaños en dp/sp, zonas táctiles reales),
 * sin redibujado continuo: la hora y la batería se actualizan con broadcasts del sistema.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var store: FortuneStore
    private lateinit var brandMark: View
    private lateinit var battery: TextView
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var continueTitle: TextView
    private lateinit var continueMeta: TextView
    private lateinit var continueAction: TextView
    private lateinit var recentTitle: TextView
    private lateinit var recentContainer: LinearLayout
    private lateinit var gestures: GestureDetector
    private var breathing: ObjectAnimator? = null

    private val timeAndBattery = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == Intent.ACTION_BATTERY_CHANGED) renderBattery(intent) else renderClock()
        }
    }

    private val packageChanges = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            AppCatalog.markStale()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Chrome.edgeToEdge(this, findViewById(R.id.home_root))
        store = FortuneStore.get(this)

        brandMark = findViewById(R.id.brand_mark)
        battery = findViewById(R.id.battery)
        clock = findViewById(R.id.clock)
        date = findViewById(R.id.date)
        continueTitle = findViewById(R.id.continue_title)
        continueMeta = findViewById(R.id.continue_meta)
        continueAction = findViewById(R.id.continue_action)
        recentTitle = findViewById(R.id.recent_title)
        recentContainer = findViewById(R.id.recent_container)

        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                if (e1 == null) return false
                val minDistance = SWIPE_MIN_DP * resources.displayMetrics.density
                val swipeUp = e1.y - e2.y > minDistance
                return if (swipeUp && abs(velocityY) > abs(velocityX) && velocityY < -SWIPE_MIN_VELOCITY) {
                    openDrawer()
                    true
                } else {
                    false
                }
            }
        })

        // El inicio no se cierra con Atrás, como cualquier launcher.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = Unit
        })

        findViewById<View>(R.id.nav_projects).setOnClickListener {
            startActivity(Intent(this, ProjectsActivity::class.java))
        }
        findViewById<View>(R.id.nav_files).setOnClickListener {
            startActivity(Intent(this, FilesActivity::class.java))
        }
        findViewById<View>(R.id.nav_settings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<View>(R.id.dock_phone).setOnClickListener {
            Launch.start(this, Intent(Intent.ACTION_DIAL), R.string.err_no_phone)
        }
        findViewById<View>(R.id.dock_messages).setOnClickListener {
            Launch.start(this, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")), R.string.err_no_sms)
        }
        findViewById<View>(R.id.dock_web).setOnClickListener {
            Launch.start(this, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")), R.string.err_no_browser)
        }
        findViewById<View>(R.id.dock_music).setOnClickListener {
            val music = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC)
            Launch.start(this, music, R.string.err_no_music)
        }
        findViewById<View>(R.id.dock_apps).setOnClickListener { openDrawer() }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        // Se observa el gesto a nivel de actividad para que los botones sigan recibiendo toques.
        gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onStart() {
        super.onStart()
        val timeFilter = IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
            addAction(Intent.ACTION_BATTERY_CHANGED)
        }
        ContextCompat.registerReceiver(this, timeAndBattery, timeFilter, ContextCompat.RECEIVER_NOT_EXPORTED)

        val packageFilter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, packageChanges, packageFilter, ContextCompat.RECEIVER_NOT_EXPORTED)

        renderClock()
        registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.let { renderBattery(it) }
    }

    override fun onStop() {
        unregisterReceiver(timeAndBattery)
        unregisterReceiver(packageChanges)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        renderHome()
        startBreathing()
    }

    override fun onPause() {
        breathing?.cancel()
        breathing = null
        super.onPause()
    }

    private fun renderHome() {
        val ordered = store.projects().sortedByDescending { it.lastAccess }
        val suggestions = store.suggestionsEnabled
        val current: Project? = if (suggestions) ordered.firstOrNull() else null

        when {
            !suggestions -> {
                continueTitle.setText(R.string.home_continue_off)
                continueMeta.visibility = View.GONE
                continueAction.visibility = View.GONE
            }
            current == null -> {
                continueTitle.setText(R.string.home_continue_empty)
                continueMeta.visibility = View.GONE
                continueAction.visibility = View.GONE
            }
            else -> {
                continueTitle.text = current.name
                continueMeta.visibility = View.VISIBLE
                continueMeta.text = getString(
                    R.string.home_continue_meta,
                    getString(current.status.labelRes),
                    Formats.relative(this, current.lastAccess)
                )
                continueAction.visibility = View.VISIBLE
                continueAction.setOnClickListener { openProject(current) }
            }
        }

        recentContainer.removeAllViews()
        val recent = if (suggestions) {
            ordered.filter { it.lastAccess > 0L && it.id != current?.id }.take(RECENT_COUNT)
        } else {
            emptyList()
        }
        recentTitle.visibility = if (recent.isEmpty()) View.GONE else View.VISIBLE
        recent.forEach { project ->
            val row = LayoutInflater.from(this).inflate(R.layout.item_recent, recentContainer, false)
            row.findViewById<TextView>(R.id.recent_name).text = project.name
            row.findViewById<TextView>(R.id.recent_meta).text = getString(
                R.string.home_continue_meta,
                getString(project.status.labelRes),
                Formats.relative(this, project.lastAccess)
            )
            row.setOnClickListener { openProject(project) }
            recentContainer.addView(row)
        }
    }

    private fun openProject(project: Project) {
        store.touch(project.id)
        val target = when {
            project.appUrl.isNotBlank() -> project.appUrl
            project.repoUrl.isNotBlank() -> project.repoUrl
            else -> null
        }
        if (target == null) {
            startActivity(
                Intent(this, ProjectDetailActivity::class.java)
                    .putExtra(ProjectDetailActivity.EXTRA_ID, project.id)
            )
        } else {
            Launch.url(this, target)
        }
    }

    private fun openDrawer() {
        startActivity(Intent(this, AppDrawerActivity::class.java))
    }

    private fun renderClock() {
        val use24Hours = DateFormat.is24HourFormat(this)
        clock.text = SimpleDateFormat(if (use24Hours) "HH:mm" else "h:mm", Locale.getDefault()).format(Date())
        date.text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault())
            .format(Date())
            .replaceFirstChar { it.titlecase(Locale.getDefault()) }
    }

    private fun renderBattery(intent: Intent) {
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        if (level < 0 || scale <= 0) {
            battery.text = ""
            return
        }
        val percent = level * 100 / scale
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        battery.text = getString(
            if (charging) R.string.home_battery_charging else R.string.home_battery,
            percent
        )
    }

    /** Respiración casi imperceptible del logotipo. Se detiene fuera de pantalla y si el usuario reduce animaciones. */
    private fun startBreathing() {
        if (breathing != null) return
        val scale = Settings.Global.getFloat(contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f)
        if (scale == 0f) return
        breathing = ObjectAnimator.ofFloat(brandMark, View.ALPHA, 0.7f, 1f).apply {
            duration = BREATH_MS
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
    }

    companion object {
        private const val SWIPE_MIN_DP = 120f
        private const val SWIPE_MIN_VELOCITY = 800f
        private const val RECENT_COUNT = 3
        private const val BREATH_MS = 4000L
    }
}
