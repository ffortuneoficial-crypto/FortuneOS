package com.fortune.os

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import com.fortune.os.data.FortuneStore
import com.fortune.os.util.Chrome
import com.fortune.os.util.Launch

class SettingsActivity : AppCompatActivity() {

    private lateinit var store: FortuneStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        Chrome.edgeToEdge(this, findViewById(R.id.settings_root))
        store = FortuneStore.get(this)

        val usage = findViewById<SwitchCompat>(R.id.sw_usage)
        usage.isChecked = store.usageTrackingEnabled
        usage.setOnCheckedChangeListener { _, checked -> store.usageTrackingEnabled = checked }
        findViewById<View>(R.id.row_usage).setOnClickListener { usage.toggle() }

        val suggestions = findViewById<SwitchCompat>(R.id.sw_suggestions)
        suggestions.isChecked = store.suggestionsEnabled
        suggestions.setOnCheckedChangeListener { _, checked -> store.suggestionsEnabled = checked }
        findViewById<View>(R.id.row_suggestions).setOnClickListener { suggestions.toggle() }

        findViewById<View>(R.id.btn_clear_usage).setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage(R.string.settings_clear_confirm)
                .setPositiveButton(R.string.common_ok) { _, _ ->
                    store.clearUsage()
                    Launch.toast(this, R.string.settings_clear_done)
                }
                .setNegativeButton(R.string.common_cancel, null)
                .show()
        }

        findViewById<View>(R.id.btn_launcher).setOnClickListener {
            Launch.start(this, Intent(Settings.ACTION_HOME_SETTINGS), R.string.settings_launcher_fail)
        }
    }
}
