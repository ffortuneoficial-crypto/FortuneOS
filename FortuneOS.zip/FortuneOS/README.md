# FortuneOS

Launcher personal para Android 15 (Nubia Neo GT 3 5G), escrito en Kotlin con Jetpack Compose.

## Funciones de la primera versión

- Pantalla principal con reloj, fecha, saludo, búsqueda, acceso rápido y zona inferior.
- Cajón de aplicaciones en cuadrícula o lista, orden alfabético y búsqueda en tiempo real.
- Favoritos (acceso rápido de inicio, hasta 8) y zona inferior (hasta 4), editables manteniendo pulsado un icono.
- Ajustes: variante visual, fondo (degradado o imagen propia), color de acento, tamaño de iconos, distribución del cajón, animaciones y restauración.
- Persistencia de preferencias con DataStore.
- Declarado como launcher (CATEGORY_HOME): puedes elegirlo como predeterminado.

## Cómo abrir y compilar

1. Descarga el ZIP desde GitHub o clona el repositorio.
2. Abre la carpeta `FortuneOS` en Android Studio (Ladybug o superior).
3. Android Studio descargará Gradle y el SDK de Android 35. Si pide generar el wrapper, acepta.
   Si no aparece, desde terminal en la carpeta ejecuta `gradle wrapper --gradle-version 8.9`
   (requiere tener Gradle instalado).
4. Conecta el teléfono con depuración USB activada y pulsa Run.
5. Para usarlo como inicio: Ajustes del teléfono > Aplicaciones > Aplicación predeterminada de inicio > FortuneOS.
   También puedes hacerlo desde Ajustes de FortuneOS > "Abrir ajustes de inicio".

## Limitaciones de Android (sin permisos especiales)

- No puede sustituir la pantalla de bloqueo, la barra de estado, el panel de notificaciones ni los gestos del sistema.
- La elección como launcher predeterminado la confirma siempre el usuario en los ajustes del sistema.
- Las funciones propias de la capa de Nubia que no tengan API pública no están disponibles.
- Para abrir el cajón se usa un deslizamiento hacia arriba en la pantalla principal, o el botón de flecha inferior.

## Estructura

```
app/src/main/java/com/fortuneos/launcher/
  MainActivity.kt          Actividad HOME (singleTask)
  FortuneApp.kt            Raíz de la interfaz y navegación
  LauncherViewModel.kt     Estado: apps, búsqueda, ajustes
  data/Models.kt           Modelos y enumeraciones de ajustes
  data/AppRepository.kt    Listado de apps, iconos, lanzamiento, cambios de paquetes
  data/PreferencesRepository.kt  Persistencia con DataStore
  ui/Components.kt         Fondo, iconos, diálogo de acciones
  ui/HomeScreen.kt         Pantalla principal
  ui/DrawerScreen.kt       Cajón y búsqueda
  ui/SettingsScreen.kt     Ajustes de FortuneOS
  ui/theme/Theme.kt        Paleta negro, carbón, petróleo y cian
```

## Próximos pasos previstos

- Pulir animaciones y transiciones con más detalle.
- Tema claro opcional y más variantes visuales.
- Búsqueda ampliada a accesos directos y contactos (fase posterior).
