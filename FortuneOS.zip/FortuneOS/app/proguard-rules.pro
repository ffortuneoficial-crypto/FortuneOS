# FortuneOS: sin reglas adicionales por ahora.
