package com.fortuneos.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.fortuneos.launcher.data.AppEntry
import com.fortuneos.launcher.data.DrawerLayout
import com.fortuneos.launcher.data.FortuneSettings

@Composable
fun DrawerScreen(
    settings: FortuneSettings,
    appMap: Map<String, AppEntry>,
    apps: List<AppEntry>,
    filtered: List<AppEntry>,
    query: String,
    loading: Boolean,
    focusSearch: Boolean,
    onQueryChange: (String) -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit,
    onBack: () -> Unit
) {
    val focusRequester = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    val iconDp = settings.iconSize.dp
    val favorites = settings.favorites.mapNotNull { appMap[it] }

    LaunchedEffect(focusSearch) {
        if (focusSearch) focusRequester.requestFocus()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Volver",
                    tint = MaterialTheme.colorScheme.onSurface
                )
            }
            SearchField(
                query = query,
                onQueryChange = onQueryChange,
                focusRequester = focusRequester,
                onSearch = {
                    keyboard?.hide()
                    // Con Enter se abre el único resultado si solo queda uno.
                    if (filtered.size == 1) onLaunch(filtered.first())
                },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(Modifier.height(12.dp))

        if (query.isBlank() && favorites.isNotEmpty()) {
            Text(
                text = "Favoritos",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(start = 8.dp, bottom = 4.dp)
            )
            LazyRow(contentPadding = PaddingValues(horizontal = 4.dp)) {
                items(items = favorites, key = { it.key }) { app ->
                    AppIcon(
                        app = app,
                        iconDp = 56,
                        showLabel = true,
                        animations = settings.animations,
                        onClick = { onLaunch(app) },
                        onLongClick = { onLongPress(app) }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        Text(
            text = if (query.isBlank()) "${apps.size} aplicaciones · A–Z"
            else "${filtered.size} de ${apps.size} aplicaciones",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 8.dp, bottom = 4.dp)
        )

        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when {
                loading && apps.isEmpty() -> CenteredMessage {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(12.dp))
                    Text("Cargando aplicaciones…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                filtered.isEmpty() -> CenteredMessage {
                    Text(
                        text = if (query.isBlank()) "No hay aplicaciones disponibles"
                        else "Sin resultados para «$query»",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                settings.drawerLayout == DrawerLayout.GRID -> LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = (iconDp + 28).dp),
                    contentPadding = PaddingValues(vertical = 8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(items = filtered, key = { it.key }) { app ->
                        AppIcon(
                            app = app,
                            iconDp = iconDp,
                            showLabel = true,
                            animations = settings.animations,
                            onClick = { onLaunch(app) },
                            onLongClick = { onLongPress(app) }
                        )
                    }
                }

                else -> LazyColumn(
                    contentPadding = PaddingValues(vertical = 8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(items = filtered, key = { it.key }) { app ->
                        AppListRow(
                            app = app,
                            onClick = { onLaunch(app) },
                            onLongClick = { onLongPress(app) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CenteredMessage(content: @Composable () -> Unit) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            content()
        }
    }
}

@Composable
private fun SearchField(
    query: String,
    onQueryChange: (String) -> Unit,
    focusRequester: FocusRequester,
    onSearch: () -> Unit,
    modifier: Modifier = Modifier
) {
    BasicTextField(
        value = query,
        onValueChange = onQueryChange,
        singleLine = true,
        textStyle = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurface),
        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        decorationBox = { inner ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .clip(RoundedCornerShape(25.dp))
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.7f))
                    .padding(horizontal = 18.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                if (query.isEmpty()) {
                    Text("Buscar aplicaciones", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                inner()
            }
        },
        modifier = modifier.focusRequester(focusRequester)
    )
}
