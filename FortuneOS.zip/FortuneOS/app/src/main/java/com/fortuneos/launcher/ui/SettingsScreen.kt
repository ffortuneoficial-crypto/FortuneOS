package com.fortuneos.launcher.ui

import android.content.Intent
import android.provider.Settings as SystemSettings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.fortuneos.launcher.LauncherViewModel
import com.fortuneos.launcher.data.Accent
import com.fortuneos.launcher.data.AppEntry
import com.fortuneos.launcher.data.DrawerLayout
import com.fortuneos.launcher.data.IconSize
import com.fortuneos.launcher.data.Slot
import com.fortuneos.launcher.data.Variant

@Composable
fun SettingsScreen(
    vm: LauncherViewModel,
    appMap: Map<String, AppEntry>,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val settings by vm.settings.collectAsState()
    var confirmReset by remember { mutableStateOf(false) }

    val pickWallpaper = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.setWallpaper(uri)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver", tint = MaterialTheme.colorScheme.onSurface)
            }
            Text("Ajustes de FortuneOS", style = MaterialTheme.typography.headlineSmall)
        }

        SectionTitle("Fondo y estilo")
        ChoiceRow(
            options = Variant.entries,
            selected = settings.variant,
            label = { it.label },
            onSelect = { v -> vm.edit { it.copy(variant = v) } }
        )
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { pickWallpaper.launch(arrayOf("image/*")) }) {
                Text("Elegir imagen de fondo")
            }
            if (settings.wallpaperUri != null) {
                Spacer(Modifier.width(8.dp))
                TextButton(onClick = { vm.clearWallpaper() }) { Text("Quitar imagen") }
            }
        }
        Text(
            text = "Una imagen propia sustituye al degradado de la variante.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp)
        )

        SectionTitle("Color de acento")
        ChoiceRow(
            options = Accent.entries,
            selected = settings.accent,
            label = { it.label },
            onSelect = { a -> vm.edit { it.copy(accent = a) } }
        )

        SectionTitle("Tamaño de iconos")
        ChoiceRow(
            options = IconSize.entries,
            selected = settings.iconSize,
            label = { it.label },
            onSelect = { s -> vm.edit { it.copy(iconSize = s) } }
        )

        SectionTitle("Cajón de aplicaciones")
        ChoiceRow(
            options = DrawerLayout.entries,
            selected = settings.drawerLayout,
            label = { it.label },
            onSelect = { d -> vm.edit { it.copy(drawerLayout = d) } }
        )

        SectionTitle("Movimiento")
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(Modifier.weight(1f)) {
                Text("Animaciones decorativas")
                Text(
                    "Transiciones y respuesta al tocar. Desactívalas para ahorrar batería.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(
                checked = settings.animations,
                onCheckedChange = { on -> vm.edit { it.copy(animations = on) } }
            )
        }

        SectionTitle("Acceso rápido de inicio")
        SlotEditor(vm, Slot.FAVORITES, settings.favorites, appMap)

        SectionTitle("Zona inferior")
        SlotEditor(vm, Slot.DOCK, settings.dock, appMap)

        SectionTitle("Launcher predeterminado")
        Text(
            text = "FortuneOS no necesita permisos especiales. Para usarlo como pantalla de inicio, " +
                "elígelo en los ajustes de inicio del sistema.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            try {
                context.startActivity(Intent(SystemSettings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
                // Si el sistema no ofrece esta pantalla, no hacemos nada.
            }
        }) {
            Text("Abrir ajustes de inicio")
        }

        SectionTitle("Restaurar")
        OutlinedButton(onClick = { confirmReset = true }) {
            Text("Restaurar configuración original")
        }
        Spacer(Modifier.height(32.dp))
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("¿Restaurar FortuneOS?") },
            text = { Text("Se borrarán tus favoritos, la zona inferior y todos los ajustes visuales.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.resetAll()
                    confirmReset = false
                }) { Text("Restaurar") }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) { Text("Cancelar") }
            }
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Spacer(Modifier.height(20.dp))
    Text(
        text = text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary
    )
    Spacer(Modifier.height(8.dp))
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun <T> ChoiceRow(
    options: List<T>,
    selected: T,
    label: (T) -> String,
    onSelect: (T) -> Unit
) {
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { option ->
            FilterChip(
                selected = option == selected,
                onClick = { onSelect(option) },
                label = { Text(label(option)) }
            )
        }
    }
}

/** Lista editable: cambiar orden, quitar y ver el estado de cada app. */
@Composable
private fun SlotEditor(
    vm: LauncherViewModel,
    slot: Slot,
    keys: List<String>,
    appMap: Map<String, AppEntry>
) {
    Text(
        text = "${keys.size} de ${slot.max} aplicaciones",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    if (keys.isEmpty()) {
        Text(
            text = "Aún no hay aplicaciones. Mantén pulsado un icono en el cajón para añadirlo.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
    keys.forEachIndexed { index, key ->
        val app = appMap[key]
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = app?.label ?: "Aplicación no instalada",
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = if (app == null) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
            )
            IconButton(enabled = index > 0, onClick = { vm.move(slot, key, -1) }) {
                Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Subir")
            }
            IconButton(enabled = index < keys.lastIndex, onClick = { vm.move(slot, key, 1) }) {
                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Bajar")
            }
            IconButton(onClick = { vm.remove(slot, key) }) {
                Icon(Icons.Default.Close, contentDescription = "Quitar")
            }
        }
    }
}
