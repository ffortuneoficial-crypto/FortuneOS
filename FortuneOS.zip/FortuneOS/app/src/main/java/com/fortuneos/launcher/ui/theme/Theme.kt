package com.fortuneos.launcher.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.fortuneos.launcher.data.Accent

val FortuneBlack = Color(0xFF07090A)
val FortuneCarbon = Color(0xFF15191C)
val FortunePetroleum = Color(0xFF0E3B43)
val FortuneText = Color(0xFFE8F1F3)
val FortuneMuted = Color(0xFF9FB3B8)

@Composable
fun FortuneTheme(accent: Accent, content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Color(accent.argb),
        onPrimary = Color(0xFF00171A),
        secondary = FortunePetroleum,
        background = FortuneBlack,
        onBackground = FortuneText,
        surface = FortuneCarbon,
        onSurface = FortuneText,
        surfaceVariant = Color(0xFF1F272B),
        onSurfaceVariant = FortuneMuted,
        outline = Color(0xFF2E3A3F)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
