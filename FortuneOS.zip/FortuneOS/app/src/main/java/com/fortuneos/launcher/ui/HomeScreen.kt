package com.fortuneos.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Settings
import com.fortuneos.launcher.data.AppEntry
import com.fortuneos.launcher.data.FortuneSettings
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(
    settings: FortuneSettings,
    apps: Map<String, AppEntry>,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit,
    onOpenDrawer: () -> Unit,
    onOpenSearch: () -> Unit,
    onOpenSettings: () -> Unit
) {
    // Reloj que se actualiza al cambiar de minuto, sin consumir recursos entre medias.
    val now by produceState(LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(60_000L - System.currentTimeMillis() % 60_000L)
        }
    }

    val locale = Locale.forLanguageTag("es-ES")
    val timeText = now.format(DateTimeFormatter.ofPattern("HH:mm"))
    val dateText = now.format(DateTimeFormatter.ofPattern("EEEE, d 'de' MMMM", locale))
        .replaceFirstChar { it.uppercase() }
    val greeting = when (now.hour) {
        in 5..12 -> "Buenos días"
        in 13..19 -> "Buenas tardes"
        else -> "Buenas noches"
    }

    val favorites = settings.favorites.mapNotNull { apps[it] }
    val dock = settings.dock.mapNotNull { apps[it] }
    val iconDp = settings.iconSize.dp
    val latestOpenDrawer by rememberUpdatedState(onOpenDrawer)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp)
            // Deslizar hacia arriba en la zona central abre el cajón.
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onVerticalDrag = { change, dy ->
                        change.consume()
                        total += dy
                    },
                    onDragEnd = { if (total < -120f) latestOpenDrawer() }
                )
            }
    ) {
        Spacer(Modifier.weight(0.7f))

        Text(
            text = timeText,
            style = TextStyle(fontSize = 84.sp, fontWeight = FontWeight.Light, letterSpacing = (-1).sp),
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = dateText,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = greeting,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.weight(0.6f))

        SearchPill(onClick = onOpenSearch)

        Spacer(Modifier.height(28.dp))

        if (favorites.isNotEmpty()) {
            AppRows(
                items = favorites,
                perRow = 4,
                iconDp = iconDp,
                showLabels = true,
                animations = settings.animations,
                onLaunch = onLaunch,
                onLongPress = onLongPress
            )
        } else {
            Text(
                text = "Mantén pulsada una aplicación en el cajón para añadirla aquí.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(Modifier.weight(0.8f))

        if (dock.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.55f))
                    .padding(vertical = 10.dp)
            ) {
                AppRows(
                    items = dock,
                    perRow = 4,
                    iconDp = iconDp,
                    showLabels = false,
                    animations = settings.animations,
                    onLaunch = onLaunch,
                    onLongPress = onLongPress
                )
            }
            Spacer(Modifier.height(8.dp))
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Spacer(Modifier.size(48.dp))
            IconButton(onClick = onOpenDrawer) {
                Icon(
                    imageVector = Icons.Default.KeyboardArrowUp,
                    contentDescription = "Todas las aplicaciones",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
            IconButton(onClick = onOpenSettings) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Ajustes de FortuneOS",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

/** Filas de iconos con un número fijo de elementos por fila. */
@Composable
private fun AppRows(
    items: List<AppEntry>,
    perRow: Int,
    iconDp: Int,
    showLabels: Boolean,
    animations: Boolean,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        items.chunked(perRow).forEach { rowItems ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                rowItems.forEach { app ->
                    AppIcon(
                        app = app,
                        iconDp = iconDp,
                        showLabel = showLabels,
                        animations = animations,
                        onClick = { onLaunch(app) },
                        onLongClick = { onLongPress(app) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}
