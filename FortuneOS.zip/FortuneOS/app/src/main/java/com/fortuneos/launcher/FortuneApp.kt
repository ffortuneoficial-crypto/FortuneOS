package com.fortuneos.launcher

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalContext
import com.fortuneos.launcher.data.AppEntry
import com.fortuneos.launcher.data.loadWallpaper
import com.fortuneos.launcher.data.launchApp
import com.fortuneos.launcher.data.openAppInfo
import com.fortuneos.launcher.ui.AppActionDialog
import com.fortuneos.launcher.ui.DrawerScreen
import com.fortuneos.launcher.ui.FortuneBackdrop
import com.fortuneos.launcher.ui.HomeScreen
import com.fortuneos.launcher.ui.SettingsScreen
import com.fortuneos.launcher.ui.theme.FortuneTheme

/** Raíz de FortuneOS: fondo, navegación entre pantallas y diálogos globales. */
@Composable
fun FortuneApp(vm: LauncherViewModel) {
    val context = LocalContext.current
    val settings by vm.settings.collectAsState()
    val apps by vm.apps.collectAsState()
    val filtered by vm.filtered.collectAsState()
    val query by vm.query.collectAsState()
    val loading by vm.loading.collectAsState()
    val screen by vm.screen.collectAsState()

    val appMap = remember(apps) { apps.associateBy { it.key } }

    val wallpaper: ImageBitmap? by produceState<ImageBitmap?>(null, settings.wallpaperUri) {
        value = settings.wallpaperUri?.let { loadWallpaper(context, Uri.parse(it)) }
    }

    var selected by remember { mutableStateOf<AppEntry?>(null) }
    var focusSearch by remember { mutableStateOf(false) }

    val launch: (AppEntry) -> Unit = { app ->
        if (!launchApp(context, app)) {
            Toast.makeText(context, "No se pudo abrir ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }
    val openDrawer: () -> Unit = {
        focusSearch = false
        vm.navigate(Screen.DRAWER)
    }
    val openSearch: () -> Unit = {
        focusSearch = true
        vm.navigate(Screen.DRAWER)
    }

    FortuneTheme(accent = settings.accent) {
        Box(Modifier.fillMaxSize()) {
            FortuneBackdrop(variant = settings.variant, wallpaper = wallpaper)

            AnimatedContent(
                targetState = screen,
                transitionSpec = {
                    if (settings.animations) {
                        (fadeIn(tween(180)) togetherWith fadeOut(tween(120)))
                    } else {
                        (EnterTransition.None togetherWith ExitTransition.None)
                    }
                },
                label = "screen"
            ) { target ->
                when (target) {
                    Screen.HOME -> HomeScreen(
                        settings = settings,
                        apps = appMap,
                        onLaunch = launch,
                        onLongPress = { selected = it },
                        onOpenDrawer = openDrawer,
                        onOpenSearch = openSearch,
                        onOpenSettings = { vm.navigate(Screen.SETTINGS) }
                    )
                    Screen.DRAWER -> DrawerScreen(
                        settings = settings,
                        appMap = appMap,
                        apps = apps,
                        filtered = filtered,
                        query = query,
                        loading = loading,
                        focusSearch = focusSearch,
                        onQueryChange = vm::setQuery,
                        onLaunch = launch,
                        onLongPress = { selected = it },
                        onBack = { vm.navigate(Screen.HOME) }
                    )
                    Screen.SETTINGS -> SettingsScreen(
                        vm = vm,
                        appMap = appMap,
                        onBack = { vm.navigate(Screen.HOME) }
                    )
                }
            }
        }
    }

    BackHandler(enabled = screen != Screen.HOME) {
        vm.navigate(Screen.HOME)
    }

    selected?.let { app ->
        AppActionDialog(
            app = app,
            settings = settings,
            onDismiss = { selected = null },
            onToggle = vm::toggle,
            onInfo = { openAppInfo(context, app) }
        )
    }
}
