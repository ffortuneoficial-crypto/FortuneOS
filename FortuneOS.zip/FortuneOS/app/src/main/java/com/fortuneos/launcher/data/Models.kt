package com.fortuneos.launcher.data

import androidx.compose.ui.graphics.ImageBitmap

/** Aplicación lanzable del sistema. [key] identifica de forma única la actividad. */
data class AppEntry(
    val key: String,
    val label: String,
    val packageName: String,
    val activityName: String,
    val icon: ImageBitmap?
)

/** Listas editables de la pantalla principal, con su capacidad máxima. */
enum class Slot(val max: Int) {
    FAVORITES(8),
    DOCK(4)
}

enum class Accent(val label: String, val argb: Long) {
    CYAN("Cian", 0xFF3FD3E0),
    TURQUOISE("Turquesa", 0xFF2EC4B6),
    ICE("Azul hielo", 0xFF7AB8FF)
}

enum class Variant(val label: String) {
    NIGHT("Noche"),
    GRAPHITE("Grafito")
}

enum class IconSize(val label: String, val dp: Int) {
    SMALL("Pequeños", 52),
    NORMAL("Normales", 60),
    LARGE("Grandes", 68)
}

enum class DrawerLayout(val label: String) {
    GRID("Cuadrícula"),
    LIST("Lista")
}

data class FortuneSettings(
    val favorites: List<String> = emptyList(),
    val dock: List<String> = emptyList(),
    val accent: Accent = Accent.CYAN,
    val iconSize: IconSize = IconSize.NORMAL,
    val drawerLayout: DrawerLayout = DrawerLayout.GRID,
    val animations: Boolean = true,
    val variant: Variant = Variant.NIGHT,
    val wallpaperUri: String? = null
)
