package com.fortuneos.launcher.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import com.fortuneos.launcher.data.AppEntry
import com.fortuneos.launcher.data.FortuneSettings
import com.fortuneos.launcher.data.Slot
import com.fortuneos.launcher.data.Variant

/** Fondo de la aplicación: imagen propia o degradado según la variante. */
@Composable
fun FortuneBackdrop(variant: Variant, wallpaper: ImageBitmap?) {
    Box(Modifier.fillMaxSize()) {
        if (wallpaper != null) {
            Image(
                bitmap = wallpaper,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.35f)))
        } else {
            val brush = when (variant) {
                Variant.NIGHT -> Brush.verticalGradient(
                    listOf(Color(0xFF07090A), Color(0xFF0B1D21), Color(0xFF0E3B43))
                )
                Variant.GRAPHITE -> Brush.verticalGradient(
                    listOf(Color(0xFF111417), Color(0xFF111417))
                )
            }
            Box(Modifier.fillMaxSize().background(brush))
        }
    }
}

/** Icono de aplicación con nombre opcional. Respuesta visual suave al pulsar. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppIcon(
    app: AppEntry,
    iconDp: Int,
    showLabel: Boolean,
    animations: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val indication = LocalIndication.current
    val scale by animateFloatAsState(
        targetValue = if (pressed && animations) 0.92f else 1f,
        label = "press"
    )

    Column(
        modifier = modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(RoundedCornerShape(16.dp))
            .combinedClickable(
                interactionSource = source,
                indication = indication,
                onClick = onClick,
                onLongClick = onLongClick
            )
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        IconBitmap(app, iconDp)
        if (showLabel) {
            Spacer(Modifier.height(6.dp))
            Text(
                text = app.label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.width((iconDp + 16).dp)
            )
        }
    }
}

/** Fila de aplicación para la distribución en lista del cajón. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppListRow(app: AppEntry, onClick: () -> Unit, onLongClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconBitmap(app, 44)
        Spacer(Modifier.width(16.dp))
        Text(
            text = app.label,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/** Icono real de la aplicación, o una inicial si todavía no está disponible. */
@Composable
internal fun IconBitmap(app: AppEntry, iconDp: Int) {
    val shape = RoundedCornerShape((iconDp * 0.22f).dp)
    val icon = app.icon
    if (icon != null) {
        Image(
            bitmap = icon,
            contentDescription = app.label,
            modifier = Modifier.size(iconDp.dp).clip(shape)
        )
    } else {
        Box(
            modifier = Modifier
                .size(iconDp.dp)
                .clip(shape)
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = app.label.take(1).uppercase(),
                color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.titleLarge
            )
        }
    }
}

/** Barra de búsqueda que abre el cajón con el teclado preparado. */
@Composable
fun SearchPill(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.7f))
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Search, contentDescription = "Buscar", tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(12.dp))
        Text("Buscar aplicaciones", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Acciones sobre una aplicación, al mantener pulsado su icono. */
@Composable
fun AppActionDialog(
    app: AppEntry,
    settings: FortuneSettings,
    onDismiss: () -> Unit,
    onToggle: (Slot, String) -> Unit,
    onInfo: () -> Unit
) {
    val inFav = app.key in settings.favorites
    val favFull = !inFav && settings.favorites.size >= Slot.FAVORITES.max
    val inDock = app.key in settings.dock
    val dockFull = !inDock && settings.dock.size >= Slot.DOCK.max

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cerrar") } },
        title = { Text(app.label) },
        text = {
            Column {
                ActionItem(
                    text = when {
                        inFav -> "Quitar de la pantalla de inicio"
                        favFull -> "Pantalla de inicio completa (máx. ${Slot.FAVORITES.max})"
                        else -> "Añadir a la pantalla de inicio"
                    },
                    enabled = inFav || !favFull
                ) {
                    onToggle(Slot.FAVORITES, app.key)
                    onDismiss()
                }
                ActionItem(
                    text = when {
                        inDock -> "Quitar de la zona inferior"
                        dockFull -> "Zona inferior completa (máx. ${Slot.DOCK.max})"
                        else -> "Añadir a la zona inferior"
                    },
                    enabled = inDock || !dockFull
                ) {
                    onToggle(Slot.DOCK, app.key)
                    onDismiss()
                }
                ActionItem("Información de la aplicación", enabled = true) {
                    onInfo()
                    onDismiss()
                }
            }
        }
    )
}

@Composable
private fun ActionItem(text: String, enabled: Boolean, onClick: () -> Unit) {
    TextButton(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(text, color = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
