package com.fortuneos.launcher

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fortuneos.launcher.data.AppEntry
import com.fortuneos.launcher.data.AppRepository
import com.fortuneos.launcher.data.FortuneSettings
import com.fortuneos.launcher.data.PreferencesRepository
import com.fortuneos.launcher.data.Slot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class Screen { HOME, DRAWER, SETTINGS }

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val appRepo = AppRepository(application)
    private val prefs = PreferencesRepository(application)

    val settings: StateFlow<FortuneSettings> = prefs.settings
        .stateIn(viewModelScope, SharingStarted.Eagerly, FortuneSettings())

    private val _apps = MutableStateFlow<List<AppEntry>>(emptyList())
    val apps: StateFlow<List<AppEntry>> = _apps.asStateFlow()

    private val _loading = MutableStateFlow(true)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    /** Apps filtradas por el texto de búsqueda, calculadas fuera del hilo principal. */
    val filtered: StateFlow<List<AppEntry>> = combine(_apps, _query) { list, q ->
        val term = q.trim()
        if (term.isEmpty()) list else list.filter { it.label.contains(term, ignoreCase = true) }
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private val _screen = MutableStateFlow(Screen.HOME)
    val screen: StateFlow<Screen> = _screen.asStateFlow()

    init {
        refreshApps()
        viewModelScope.launch {
            appRepo.packageChanges().debounce(400).collect { refreshApps() }
        }
    }

    fun refreshApps() {
        viewModelScope.launch {
            _loading.value = true
            _apps.value = appRepo.loadApps()
            _loading.value = false
        }
    }

    fun navigate(target: Screen) {
        _screen.value = target
        if (target == Screen.HOME) _query.value = ""
    }

    fun setQuery(text: String) {
        _query.value = text
    }

    fun edit(transform: (FortuneSettings) -> FortuneSettings) {
        viewModelScope.launch { prefs.update(transform) }
    }

    /** Añade o quita una aplicación de una lista, respetando el máximo. */
    fun toggle(slot: Slot, key: String) = edit { s ->
        s.withList(slot) { list ->
            when {
                key in list -> list - key
                list.size < slot.max -> list + key
                else -> list
            }
        }
    }

    fun move(slot: Slot, key: String, delta: Int) = edit { s ->
        s.withList(slot) { list ->
            val i = list.indexOf(key)
            val j = i + delta
            if (i < 0 || j !in list.indices) list
            else list.toMutableList().apply { add(j, removeAt(i)) }
        }
    }

    fun remove(slot: Slot, key: String) = edit { s ->
        s.withList(slot) { it - key }
    }

    private fun FortuneSettings.withList(slot: Slot, f: (List<String>) -> List<String>): FortuneSettings =
        when (slot) {
            Slot.FAVORITES -> copy(favorites = f(favorites))
            Slot.DOCK -> copy(dock = f(dock))
        }

    fun setWallpaper(uri: Uri) {
        try {
            getApplication<Application>().contentResolver
                .takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: SecurityException) {
            // Algunos proveedores no permiten permisos persistentes; la imagen se usará igualmente en esta sesión.
        }
        edit { it.copy(wallpaperUri = uri.toString()) }
    }

    fun clearWallpaper() = edit { it.copy(wallpaperUri = null) }

    fun resetAll() {
        viewModelScope.launch { prefs.reset() }
    }
}
