package com.fortuneos.launcher.data

import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.BitmapFactory
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.net.Uri
import android.provider.Settings as SystemSettings
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.withContext

/** Resolución de los iconos cacheados. 144 px cubre bien 68 dp en pantallas de alta densidad. */
private const val ICON_PX = 144

class AppRepository(private val context: Context) {

    /** Lista todas las aplicaciones lanzables, ordenadas alfabéticamente. */
    suspend fun loadApps(): List<AppEntry> = withContext(Dispatchers.Default) {
        val pm = context.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(query, 0)
            .asSequence()
            .filter { it.activityInfo.packageName != context.packageName }
            .mapNotNull { runCatching { it.toEntry(pm) }.getOrNull() }
            .distinctBy { it.key }
            .sortedBy { it.label.lowercase() }
            .toList()
    }

    /** Emite un evento cuando se instala, actualiza o desinstala una aplicación. */
    fun packageChanges(): Flow<Unit> = callbackFlow {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                trySend(Unit)
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(context, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        awaitClose { context.unregisterReceiver(receiver) }
    }

    private fun ResolveInfo.toEntry(pm: PackageManager): AppEntry {
        val ai = activityInfo
        return AppEntry(
            key = "${ai.packageName}/${ai.name}",
            label = loadLabel(pm).toString(),
            packageName = ai.packageName,
            activityName = ai.name,
            icon = loadIcon(pm).toBitmap(ICON_PX, ICON_PX).asImageBitmap()
        )
    }
}

/** Abre una aplicación. Devuelve false si no fue posible. */
fun launchApp(context: Context, app: AppEntry): Boolean = try {
    val intent = Intent(Intent.ACTION_MAIN)
        .addCategory(Intent.CATEGORY_LAUNCHER)
        .setComponent(ComponentName(app.packageName, app.activityName))
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    context.startActivity(intent)
    true
} catch (e: ActivityNotFoundException) {
    false
} catch (e: SecurityException) {
    false
}

/** Abre la pantalla de información de sistema de una aplicación. */
fun openAppInfo(context: Context, app: AppEntry) {
    try {
        val intent = Intent(
            SystemSettings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.fromParts("package", app.packageName, null)
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        // Sin acción disponible: no hacemos nada.
    }
}

/** Carga una imagen de fondo elegida por el usuario, reducida para ahorrar memoria. */
suspend fun loadWallpaper(context: Context, uri: Uri): ImageBitmap? = withContext(Dispatchers.IO) {
    runCatching {
        context.contentResolver.openInputStream(uri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, BitmapFactory.Options().apply { inSampleSize = 2 })
                ?.asImageBitmap()
        }
    }.getOrNull()
}
