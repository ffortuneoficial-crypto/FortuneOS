package com.fortuneos.launcher.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.dataStore by preferencesDataStore(name = "fortuneos_prefs")

private object Keys {
    val FAVORITES = stringPreferencesKey("favorites")
    val DOCK = stringPreferencesKey("dock")
    val ACCENT = stringPreferencesKey("accent")
    val ICON_SIZE = stringPreferencesKey("icon_size")
    val DRAWER_LAYOUT = stringPreferencesKey("drawer_layout")
    val ANIMATIONS = booleanPreferencesKey("animations")
    val VARIANT = stringPreferencesKey("variant")
    val WALLPAPER = stringPreferencesKey("wallpaper")
}

private const val SEP = "|"

private fun String?.toKeyList(): List<String> =
    this?.split(SEP)?.filter { it.isNotBlank() } ?: emptyList()

private inline fun <reified T : Enum<T>> String?.toEnumOr(default: T): T =
    enumValues<T>().firstOrNull { it.name == this } ?: default

private fun Preferences.toSettings() = FortuneSettings(
    favorites = this[Keys.FAVORITES].toKeyList(),
    dock = this[Keys.DOCK].toKeyList(),
    accent = this[Keys.ACCENT].toEnumOr(Accent.CYAN),
    iconSize = this[Keys.ICON_SIZE].toEnumOr(IconSize.NORMAL),
    drawerLayout = this[Keys.DRAWER_LAYOUT].toEnumOr(DrawerLayout.GRID),
    animations = this[Keys.ANIMATIONS] ?: true,
    variant = this[Keys.VARIANT].toEnumOr(Variant.NIGHT),
    wallpaperUri = this[Keys.WALLPAPER]
)

/** Persistencia de ajustes con DataStore. Cada cambio es atómico. */
class PreferencesRepository(private val context: Context) {

    val settings: Flow<FortuneSettings> = context.dataStore.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { it.toSettings() }

    suspend fun update(transform: (FortuneSettings) -> FortuneSettings) {
        context.dataStore.edit { prefs ->
            val n = transform(prefs.toSettings())
            prefs[Keys.FAVORITES] = n.favorites.joinToString(SEP)
            prefs[Keys.DOCK] = n.dock.joinToString(SEP)
            prefs[Keys.ACCENT] = n.accent.name
            prefs[Keys.ICON_SIZE] = n.iconSize.name
            prefs[Keys.DRAWER_LAYOUT] = n.drawerLayout.name
            prefs[Keys.ANIMATIONS] = n.animations
            prefs[Keys.VARIANT] = n.variant.name
            val wp = n.wallpaperUri
            if (wp == null) prefs.remove(Keys.WALLPAPER) else prefs[Keys.WALLPAPER] = wp
        }
    }

    suspend fun reset() {
        context.dataStore.edit { it.clear() }
    }
}
