package com.fortuneos.launcher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels

class MainActivity : ComponentActivity() {

    private val vm: LauncherViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { FortuneApp(vm) }
    }

    /** Al pulsar el botón de inicio con FortuneOS ya abierto, volvemos a la pantalla principal. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        vm.navigate(Screen.HOME)
    }
}
